window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "ECSD Kiosk APP",
   "homepage": "https://ecsd-gituser.github.io/Kiosk-Webpage/",
   "enableNavBttns": true,
   "enableHomeBttn": true,
   "enableReloadBttn": true,
   "sessionDataTimeoutTime": 2,
   "sessionTimeoutTime": 3,
   "kioskEnabled": true
};